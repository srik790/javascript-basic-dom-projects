// ****** select items **********
const btnSuprise = document.getElementById(btnSuprise);
const divSup = document.getElementById(divSup);
// ****** event listeners **********
// submit form
btnSuprise.addEventListener(click);

// ****** functions **********

function show(){
  divSup.style.display = 'none';
}
