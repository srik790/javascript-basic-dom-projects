// ****** select items **********
const btnRead = document.getElementById("btn1Read");
const paragraph = document.getElementById(paragraph);
// ****** event listeners **********
// submit form
btn.Read.addEventListener("click", showParagraph);

// ****** functions **********

function handleClick(){
  paragraph.style.displayStyle = 'block';
  btnRead.style.display = 'none';
}
